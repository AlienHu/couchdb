#define SM185 
#define HAVE_JS_GET_STRING_CHARS_AND_LENGTH 1
#define JSSCRIPT_TYPE JSObject*
#define COUCHJS_NAME "couchjs"
#define PACKAGE "apache-couchdb"
#define PACKAGE_BUGREPORT "https://issues.apache.org/jira/browse/COUCHDB"
#define PACKAGE_NAME "Apache CouchDB"
#define PACKAGE_STRING "Apache CouchDB 2.1.0-72-g3b8b9a3f4"
#define PACKAGE_VERSION "2.1.0-72-g3b8b9a3f4"
